package com.example.trabalho2bimestre;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroItemActivity extends AppCompatActivity {
}
