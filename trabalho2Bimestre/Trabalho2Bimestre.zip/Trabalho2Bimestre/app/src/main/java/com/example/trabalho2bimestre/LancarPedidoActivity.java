package com.example.trabalho2bimestre;

import androidx.appcompat.app.AppCompatActivity;

public class LancarPedidoActivity extends AppCompatActivity {
}
